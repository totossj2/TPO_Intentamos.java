package ControladorCurso;

import java.util.*;


public class ControladorCursos {

    public ControladorCursos() {
    }

    private List<Curso> listaCursos;

    public void asignarDocente(Docente docente) {
        // TODO implement here
    }

    public void getIDCurso() {
        // TODO implement here
    }
    public void getCronogramaSemanal() {
        // TODO implement here
    }

    public void getNombre() {
        // TODO implement here
    }

    public void getHorario() {
        // TODO implement here
    }

    public void getAula() {
        // TODO implement here
    }

    public List<Curso> getCursos(){
        return listaCursos;
    }

    private Curso curso;
    private ControladorCursos controladorCursos;

    public List<Integer> obtenerCursoXMateria(int idMateria) {
        List<Curso> cursos = controladorCursos.getCursos();
        List<Integer> cursos_materia = null;
        for (Curso curso : cursos) {
            if (curso.getIdMateria() == idMateria){
                cursos_materia.add(curso.getIdCurso());
            };
        }
        return cursos_materia;
    }

}