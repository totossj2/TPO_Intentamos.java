package ControladorCurso;

import ControladorInformes.Informe;
import ControladorCurso.Curso;

import java.util.*;
/**
 * 
 */
public class Docente {

    /**
     * Default constructor
     */
    public Docente() {
    }

    /**
     * 
     */
    private int legajo;

    /**
     * 
     */
    private List<Curso> listaCursosXCuatrimestre;

    /**
     * 
     */

    private Map <Curso,Informe> mapInformesXCurso;

    /**
     * 
     */
    public void getCursosAsignados() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getCronogramaSemanal() {
        // TODO implement here
    }

}