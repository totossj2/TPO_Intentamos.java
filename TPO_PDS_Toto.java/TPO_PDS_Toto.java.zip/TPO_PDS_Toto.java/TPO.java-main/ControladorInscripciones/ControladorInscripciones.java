package ControladorInscripciones;

import ControladorCarrera.ControladorCarrera;
import ControladorMateria.ControladorMateria;
import ControladorCurso.Curso;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class ControladorInscripciones {

    public ControladorInscripciones() {
    }

    private Alumno alumno;

    private Inscripcion inscripcion;

    private Cuatrimestre cuatrimestre;

    private LocalDate fechaActual;

    ControladorMateria controladorMateria = new ControladorMateria();
    ControladorCarrera controladorCarrera = new ControladorCarrera();


    public void inscribirse(Alumno alumno, Curso curso){
        int idMateria = curso.getIdMateria();
        if (checkCorrelativas(idMateria, alumno.getidAlumno()) != null) {
            System.out.println("No cumple con las correlativas");
            for (int correlativa : checkCorrelativas(idMateria, alumno.getidAlumno())) {
                System.out.println("Falta"+correlativa);
            }
            return;
        }
        if (!esFechaValida()) {
            System.out.println("No es fecha valida");
            return;
        }
        if (!controlarCargaHorariaXCurso()) {
            System.out.println("No cumple con la carga horaria");
            return;
        }
        verCursos(idMateria);
        System.out.println("Inscripcion exitosa");
        // falta q pago, q se aumente la carga horaria en cuatrimestre y q se agregue la materia a la lista de materias  del alumno

        float horasAcumuladas = controladorMateria.getMateria(idMateria);
        cuatrimestre.aumentarHoras(horasAcumuladas);
        cuatrimestre.agregarCursada(idMateria);

    }

    public void verCursos(int materiaID) {
        List<Integer> cursos = controladorMateria.getCursosAsignados(materiaID);
        for (int curso : cursos) {
            System.out.println(curso);
        }
    }

    public List<Integer> checkCorrelativas(int idMateria, int idAlumno) {
        List<Integer> correlativasAnteriores = controladorMateria.getCorrelativasAnteriores(idMateria);
        List<Integer> materiasAprobadas = alumno.getListaMateriasAprobadas();
        List<Integer> materiasRestantes = correlativasAnteriores;


        for (int correlativa : correlativasAnteriores) {
            if (materiasAprobadas.contains(correlativa)) {
                materiasRestantes.remove(correlativa);
            }
        }
        return materiasRestantes;
    } //estara adentro de inscribirse, devuele tmb las materias q falta aprobar en ese caso.

    public boolean esFechaValida(){
        if (this.fechaActual.isAfter(inscripcion.getFechaLimite())) {
            return true;
        } else {
            return false;
        }
    } // estara adentro d inscribirse

    public boolean controlarCargaHorariaXCurso() {
        Float horasAcumuladas = cuatrimestre.getCargaHoraria(); // Cuando hagamos Inscribirse, hay q aumentar las horas en cuatrimestre con cuatrimeste.sumarHoras();
        Float HorasMaximas = controladorCarrera.getCargaHorariamaxima();
        if (horasAcumuladas > HorasMaximas) {
            return false;
        } else {
            return true;
        }
    }

}