package ControladorInscripciones;

import java.util.*;
public class Alumno {

    public Alumno(int idAlumno, int legajo, String nombre, String email) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.email = email;
    }
    private List<Integer> listaMateriasAprobadas;

    private int legajo;

    private int idAlumno;
    private String nombre;

    private String email;

    private int telefono;

    public int getidAlumno() {
        return idAlumno;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Integer> getListaMateriasAprobadas() {
        return listaMateriasAprobadas;
    }
}