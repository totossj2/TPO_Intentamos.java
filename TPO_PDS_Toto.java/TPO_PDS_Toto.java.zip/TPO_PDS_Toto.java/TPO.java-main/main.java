import ControladorCurso.Curso;
import ControladorInscripciones.Alumno;
import ControladorInscripciones.ControladorInscripciones;
import ControladorMateria.Materia;
import ControladorMateria.ControladorMateria;


public class main {
    public static void main(String[] args) {
        Alumno alumno = new Alumno(1,1, "Juan", "juanpedro@gmail.com");
        Materia materia = new Materia(1, "Calculo I",4.0, "Fisica II", "Calculo II");
        Curso materia = new Curso(1, 1);
        Curso materia2 = new Curso(2, 2);

        ControladorInscripciones controladorInscripciones = new ControladorInscripciones();
        controladorInscripciones.inscribirse(alumno, materia);
        controladorInscripciones.inscribirse(alumno, materia2);
    }
}  cxzcz
        ndasdas