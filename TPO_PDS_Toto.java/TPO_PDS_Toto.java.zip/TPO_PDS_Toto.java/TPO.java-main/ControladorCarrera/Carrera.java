package ControladorCarrera;

import java.util.*;

public class Carrera {

    public Carrera(List<Integer> listaMateria, String nombre, int duracion, float cargaHorariaMaxima) {
        this.listaMateria = listaMateria;
        this.nombre = nombre;
        this.duracion = duracion;
        this.cargaHorariaMaxima = cargaHorariaMaxima;
    }

    private String nombre;

    private int duracion;

    private List <Integer> listaMateria;

    private Float cargaHorariaMaxima;

    public Float getCargaHorariaMaxima() {
        return cargaHorariaMaxima;
    }

}