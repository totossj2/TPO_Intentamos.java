package ControladorCarrera;

/**
 * 
 */
public class ControladorCarrera {

    private Carrera carrera;

    public ControladorCarrera() {
    }

    public void agregarCarrera() {
        // TODO implement here
    }

    public void getCarrera(String nombre) {
        // TODO implement here
    }



    public Float getCargaHorariamaxima() {
        return carrera.getCargaHorariaMaxima();
    }
}