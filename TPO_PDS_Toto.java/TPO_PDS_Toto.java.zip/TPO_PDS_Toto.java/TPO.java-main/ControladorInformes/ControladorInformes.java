package ControladorInformes;

import java.util.*;

/**
 * 
 */
public class ControladorInformes {

    /**
     * Default constructor
     */
    public ControladorInformes() {
    }

    /**
     * 
     */
    public void generarInformeXCursoAsignado() {
        // TODO implement here
    }

}