package ControladorInformes;

/**
 * 
 */
public abstract class Informe {

    public Informe() {
    }

    private String nombre;

    private Float horario;

    private int aulaAsiganada;


    /**private void generarInforme(Curso curso) {
        // TODO implement here
    }**/

}