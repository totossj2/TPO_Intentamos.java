package ControladorInformes;

import ControladorCurso.Curso;
import ControladorInformes.Informe;

public class PDF extends Informe {
    public PDF() {
    }
    public void generarInformer(Curso curso) {
        // TODO implement here
    }

}