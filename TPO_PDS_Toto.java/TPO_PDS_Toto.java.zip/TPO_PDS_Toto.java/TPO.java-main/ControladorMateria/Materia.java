package ControladorMateria;

import ControladorCurso.Curso;

import java.util.*;

/**
 * 
 */
public class Materia {

    public Materia(int idMateria, String nombre, Float cargaHoraria, String CorrelativaPosterior, String CorrelativaAnterior) {
        this.idMateria = idMateria;
        this.nombre = nombre;
        this.cargaHoraria = cargaHoraria;
        this.CorrelativaPosterior = CorrelativaPosterior;
        this.CorrelativaAnterior = CorrelativaAnterior;
    }

    private int idMateria;


    private List<Curso> listaCursos;

    private String nombre;

    private Float cargaHoraria;

    private String CorrelativaPosterior;

    private String CorrelativaAnterior;

    private List<Integer> correlativasPosteriores;

    private List<Integer> correlativasAnteriores;

    public int getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(int idMateria) {
        this.idMateria = idMateria;
    }

    public List<Integer> getCorrelativasAnteriores(){
        return correlativasAnteriores;
    }

    public float getCargaHoraria() {
        return cargaHoraria;
    }
}