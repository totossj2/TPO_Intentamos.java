package ControladorMateria;

import ControladorCurso.ControladorCursos;
import ControladorCurso.Curso;

import java.util.*;

public class ControladorMateria {

    public ControladorMateria() {
    }

    private ControladorCursos controladorCurso;

    private List<Materia> listaMaterias;

    private Materia materia;

    public List<Integer> getCursosAsignados(int materiaID){
        return controladorCurso.obtenerCursoXMateria(materiaID);
    }

    public void agregarMateria(Materia materia){
        listaMaterias.add(materia);
    }
    public List<Integer> getCorrelativasAnteriores(int idMateria){
        for (Materia materia : listaMaterias){
            if (materia.getIdMateria() == idMateria){
                return materia.getCorrelativasAnteriores();
            }
        }
        List<Integer> listaVacia = new ArrayList<Integer>();
        return listaVacia;
    }

    public float getMateria(int idMateria) {
        return materia.getCargaHoraria();
    }
}